package utils;

/**
 * Created by Administrator on 2016/10/29.
 */
public final class BindViewConfig {
    public static final String DIALIG_TITLE = "BindView";
    public static final String BindView = "@BindView";
    public static final String BindOnClick = "@BindOnClick";
    public static final String BindOnLongClick = "@BindOnLongClick";
}
