package com.liangmayong.base.iconfont;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class FontParserV2 {

	public static void create(String fonts,String packageName,
			String className, String fontPath,String output) {
		Map<String, String> values = readValue(fonts+"/"+FontConstant.V2_DEMO_FONTCLASS,fonts+"/"+FontConstant.V2_DEMO_UNICODE);
		FontFile.saveFile(packageName, className, fontPath, values,output);
	}
	
	private static Map<String, String> readValue(String classPath,
			String codePath) {
		// read class
		Map<String, String> values = new HashMap<String, String>();
		String html = FontFile.readFile(classPath, "utf-8");
		Document doc = Jsoup.parse(html);
		Elements icons = doc.getElementsByTag("li");
		Document icondoc = null;
		List<String> classes = new ArrayList<String>();
		for (Element link : icons)
			try {
				icondoc = Jsoup.parse(link.html());
				String name = icondoc.getElementsByClass("fontclass").text();
				String key = "icon_"
						+ name.substring(5).replaceAll(".icon", "")
								.replaceAll("-", "_").replaceAll(" ", "")
								.substring(1);
				classes.add(key);
			} catch (Exception localException) {
			}

		// read unicode
		String codeHtml = FontFile.readFile(codePath, "utf-8");
		Document codeDoc = Jsoup.parse(codeHtml);
		Elements codeIcons = codeDoc.getElementsByTag("li");
		Document codeIcondoc = null;
		List<String> codes = new ArrayList<String>();
		for (Element link : codeIcons)
			try {
				codeIcondoc = Jsoup.parse(link.html());
				String code = codeIcondoc.getElementsByClass("code").text()
						.toLowerCase();
				String value = code.replaceAll("&#x", "").replaceAll(";", "");
				codes.add(value);
			} catch (Exception localException1) {
			}
		for (int i = 0; i < Math.min(codes.size(), classes.size()); i++) {
			values.put((String) classes.get(i), (String) codes.get(i));
		}
		return values;
	}
}
