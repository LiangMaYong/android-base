package com.liangmayong.base.iconfont;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;

public class FontFile {

	public static void saveFile(String packageName, String className,
			String fontPath, Map<String, String> values, String outputDir) {
		if (values == null || values.isEmpty()) {
			System.out.println("failure");
			return;
		}
		if (outputDir == null) {
			outputDir = "./";
		}
		// font value
		String contentValue = "";
		contentValue += getHeadValue(packageName, className);
		contentValue += "\tpublic static final String PATH = \"" + fontPath
				+ "\";\n\n";
		for (Map.Entry<String, String> entry : values.entrySet()) {
			contentValue = contentValue + "\tpublic static final FontValue "
					+ (String) entry.getKey() + " = new FontValue(PATH," + "0x"
					+ entry.getValue() + "" + ");" + "\n";
		}
		contentValue += getFooter();

		String contentXML = "<resources>";
		contentXML += "\n";
		for (Map.Entry<String, String> entry : values.entrySet()) {
			contentXML += "\t<string name=\"" + entry.getKey() + "\">&#x"
					+ entry.getValue() + ";</string>";
			contentXML += "\n";
		}
		contentXML += "</resources>";
		try {
			writeFile(outputDir + className + ".java", contentValue);
			writeFile(outputDir + className + ".xml", contentXML);
			System.out.println("successful");
		} catch (Exception e) {
			System.out.println("failure");
			System.out.println(e);
		}
	}

	private static String getHeadValue(String packageName, String className) {
		String head = "package " + packageName + ";";
		head += "\n";
		head += "\n";
		head += "import com.liangmayong.base.widget.iconfont.FontValue;";
		head += "\n";
		head += "\n";
		head += "import android.content.Context;";
		head += "\n\n/**\n* " + className;
		head += "\n*\n* @author LiangMaYong\n* @version 1.0 \n**/";
		head += "\npublic final class " + className + " {\n";
		head += "\n";
		head += "\n\tprivate " + className + " (){}\n\n";
		return head;
	}

	private static String getFooter() {
		return "\n}";
	}

	private static void writeFile(String filename, String content)
			throws Exception {
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File(
				filename)));
		writer.write(content);
		writer.close();
	}

	/**
	 * readFile
	 * 
	 * @param fileName
	 *            fileName
	 * @param charsetName
	 *            charsetName
	 * @return content
	 */
	protected static String readFile(String fileName, String charsetName) {
		File file = new File(fileName);
		BufferedReader reader = null;
		String content = "";
		try {
			InputStreamReader isr = new InputStreamReader(new FileInputStream(
					file), charsetName);
			reader = new BufferedReader(isr);
			String tempString = null;
			while ((tempString = reader.readLine()) != null) {
				content += tempString;
			}
			reader.close();
		} catch (IOException e) {
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e1) {
				}
			}
		}
		return content;
	}
}
