package com.liangmayong.base.iconfont;

public class FontConstant {

	// iconfont v1
	public static final String V1_DEMO = "demo.html";

	// iconfont v2
	public static final String V2_DEMO_FONTCLASS = "demo_fontclass.html";
	public static final String V2_DEMO_UNICODE = "demo_unicode.html";
	

	// default
	public static final String DEFAULT_FONTPATH = "fonts/base_iconfont.ttf";
	public static final String DEFAULT_PACKAGENAME = "com.liangmayong.base.widget.iconfont";
	public static final String DEFAULT_CLASSNAME = "IconFont";
}
