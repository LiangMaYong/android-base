package com.liangmayong.base.iconfont;

import java.util.HashMap;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public final class FontParserV1 {

	private FontParserV1() {
	}

	public static void create(String fonts, String packageName,
			String className, String fontPath,String output) {
		Map<String, String> values = readValue(fonts+"/"+FontConstant.V1_DEMO);
		FontFile.saveFile(packageName, className, fontPath, values,output);
	}

	private static Map<String, String> readValue(String readPath) {
		Map<String, String> values = new HashMap<String, String>();
		String html = FontFile.readFile(readPath, "utf-8");
		Document doc = Jsoup.parse(html);
		Elements icons = doc.getElementsByTag("li");
		Document icondoc = null;
		for (Element link : icons) {
			icondoc = Jsoup.parse(link.html());
			String name = icondoc.getElementsByClass("fontclass").text();
			String code = icondoc.getElementsByClass("code").text()
					.toLowerCase();
			String key = "icon_"
					+ name.replaceAll(".icon", "").replaceAll("-", "_")
							.replaceAll(" ", "").substring(1);
			String value = code.replaceAll("&#x", "").replaceAll(";", "");
			values.put(key, value);
		}
		return values;
	}

}
