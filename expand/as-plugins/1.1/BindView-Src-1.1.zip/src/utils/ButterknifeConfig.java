package utils;

/**
 * Created by Administrator on 2016/10/29.
 */
public final class ButterknifeConfig {
    public static final String BindView = "@BindView";
    public static final String BindOnClick = "@OnClick";
    public static final String BindOnLongClick = "@OnLongClick";
}
