package listener;

public interface ICancelListener {

    void onCancel();
}
