package com.liangmayong.base.iconfont;

import java.io.File;

public class FontMain {

	private static String getVersion(String fonts) {
	    File v1File = new File(fonts+"/"+FontConstant.V1_DEMO);
	    if (v1File.exists()) {
	    	return "v1";
	    }
	    File v2ClassFile = new File(fonts+"/"+FontConstant.V2_DEMO_FONTCLASS);
	    File v2UnicodeFile = new File(fonts+"/"+FontConstant.V2_DEMO_UNICODE);
	    if (v2ClassFile.exists()&&v2UnicodeFile.exists()) {
	    	return "v2";
	    }
		return "unkown";
	}

	public static void main(String[] args) {
		if ((args.length > 0 && "-help".equals(args[0].toLowerCase()))||args.length == 0) {
			// help
			System.out.println("|-----------------------------------|");
			System.out.println("|===========     HELP    ===========|");
			System.out.println("|-----------------------------------|");
			System.out.println("|                                   |");
			System.out.println("| -help :   show help         ------|");
			System.out.println("| -d    :   Input dir         ------|");
			System.out.println("| -p    :   Package name      ------|");
			System.out.println("| -f    :   Font file path    ------|");
			System.out.println("| -n    :   Class name        ------|");
			System.out.println("| -o    :   Output dir        ------|");
			System.out.println("| -v    :   Icon font version ------|");
			System.out.println("|                                   |");
			System.out.println("|-----------------------------------|");
		} else {
			// main
			String fonts = "./";
			String fontPath = FontConstant.DEFAULT_FONTPATH;
			String className = FontConstant.DEFAULT_CLASSNAME;
			String packageName = FontConstant.DEFAULT_PACKAGENAME;
			String version = null;
			String output = null;

			for (int i = 0; i < args.length; i++) {
				if ("-d".equals(args[i]) && i + 1 < args.length) {
					fonts = args[i + 1];
				}
				if ("-p".equals(args[i]) && i + 1 < args.length) {
					packageName = args[i + 1];
				}
				if ("-f".equals(args[i]) && i + 1 < args.length) {
					fontPath = args[i + 1];
				}
				if ("-n".equals(args[i]) && i + 1 < args.length) {
					className = args[i + 1];
				}
				if ("-o".equals(args[i]) && i + 1 < args.length) {
					output = args[i + 1];
				}
				if ("-v".equals(args[i]) && i + 1 < args.length) {
					version = args[i + 1].toLowerCase();
				}
			}
			File file = new File(fonts);
			if (!file.exists()) {
				System.out.println("failure : "+fonts+" directory does not exist");
				return;
			}
			if (version == null) {
				version = getVersion(fonts).toLowerCase();
			}

			if ("v1".equals(version)) {
				FontParserV1.create(fonts, packageName, className,
						fontPath, output);
			} else if ("v2".equals(version)) {
				FontParserV2.create(fonts, packageName, className,
						fontPath, output);
			} else {
				System.out.println("failure : parse error");
			}
		}
	}
}
