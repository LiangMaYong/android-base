package utils;

import com.intellij.codeInsight.actions.ReformatCodeProcessor;
import com.intellij.openapi.command.WriteCommandAction;
import com.intellij.openapi.project.Project;
import com.intellij.psi.*;
import com.intellij.psi.codeStyle.JavaCodeStyleManager;
import com.intellij.psi.search.EverythingGlobalScope;
import entity.Element;
import org.apache.http.util.TextUtils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class BindView extends WriteCommandAction.Simple {

    protected PsiFile mFile;
    protected Project mProject;
    protected PsiClass mClass;
    protected ArrayList<Element> mElements;
    protected PsiElementFactory mFactory;
    protected String mLayoutFileName;
    protected String mFieldNamePrefix;
    protected boolean mCreateHolder;
    protected boolean mBind;
    protected boolean mButterknife;

    public BindView(PsiFile file, PsiClass clazz, String command, ArrayList<Element> elements, String layoutFileName, String fieldNamePrefix, boolean bind, boolean butterknife, boolean createHolder) {
        super(clazz.getProject(), command);
        mFile = file;
        mProject = clazz.getProject();
        mClass = clazz;
        mElements = elements;
        mFactory = JavaPsiFacade.getElementFactory(mProject);
        mLayoutFileName = layoutFileName;
        mFieldNamePrefix = fieldNamePrefix;
        mCreateHolder = createHolder;
        mButterknife = butterknife;
        mBind = bind;
    }

    @Override
    public void run() throws Throwable {
        if (mCreateHolder) {
            generateAdapter();
        } else {
            if (mBind) {
                generatorBindView();
                generatorBindOnClick();
                generatorBindLongOnClick();
                generatorEditSubmit();
            } else {
                generateFields();
                generateInitViews();
                generatorEditSubmit();
            }
        }

        // reformat class
        JavaCodeStyleManager styleManager = JavaCodeStyleManager.getInstance(mProject);
        styleManager.optimizeImports(mFile);
        styleManager.shortenClassReferences(mClass);
        new ReformatCodeProcessor(mProject, mClass.getContainingFile(), null, false).runWithoutProgress();
    }

    /**
     * Create ViewHolder for adapters with injections
     */
    protected void generateAdapter() {
        // view holder class
        String holderClassName = Utils.getViewHolderClassName();
        PsiClass innerClass = mClass.findInnerClassByName(holderClassName, false);
        if (innerClass != null) {
            Utils.showErrorNotification(mProject, holderClassName + " is exist!");
            return;
        }
        StringBuilder holderBuilder = new StringBuilder();

        // generator of view holder class
        StringBuilder generator = new StringBuilder();
        generator.append("public " + holderClassName + "(android.view.View rootView) {\n");

        // rootView
        String rootViewName = "rootView";
        holderBuilder.append("public " + "android.view.View " + rootViewName + ";\n");
        generator.append("this." + rootViewName + " = " + rootViewName + ";\n");

        for (Element element : mElements) {
            if (!element.used) {
                continue;
            }

            // field
            holderBuilder.append("public " + element.name + " " + element.getFieldName() + ";\n");

            // findViewById in generator
            generator.append("this." + element.getFieldName() + " = (" + element.name + ") "
                    + rootViewName + ".findViewById(" + element.getFullID() + ");\n");
        }
        generator.append("}\n");

        holderBuilder.append(generator.toString());

        PsiClass viewHolder = mFactory.createClassFromText(holderBuilder.toString(), mClass);
        viewHolder.setName(holderClassName);
        mClass.add(viewHolder);
        mClass.addBefore(mFactory.createKeyword("public", mClass), mClass.findInnerClassByName(holderClassName, true));
        //mClass.addBefore(mFactory.createKeyword("static", mClass), mClass.findInnerClassByName(holderClassName, true));
    }

    /**
     * Create fields for injections inside main class
     */
    protected void generateFields() {
        for (Iterator<Element> iterator = mElements.iterator(); iterator.hasNext(); ) {
            Element element = iterator.next();

            if (!element.used) {
                continue;
            }

            // remove duplicate field
            PsiField[] fields = mClass.getFields();
            boolean duplicateField = false;
            for (PsiField field : fields) {
                String name = field.getName();
                if (name != null && name.equals(element.getFieldName())) {
                    duplicateField = true;
                    break;
                }
            }
            if (duplicateField) {
                continue;
            }
            mClass.add(mFactory.createFieldFromText("private " + element.name + " " + element.getFieldName() + ";", mClass));
        }
    }

    protected void generateInitViews() {
        PsiClass activityClass = JavaPsiFacade.getInstance(mProject).findClass(
                "android.app.Activity", new EverythingGlobalScope(mProject));
        PsiClass compatActivityClass = JavaPsiFacade.getInstance(mProject).findClass(
                "android.support.v7.app.AppCompatActivity", new EverythingGlobalScope(mProject));
        PsiClass fragmentClass = JavaPsiFacade.getInstance(mProject).findClass(
                "android.app.Fragment", new EverythingGlobalScope(mProject));
        PsiClass supportFragmentClass = JavaPsiFacade.getInstance(mProject).findClass(
                "android.support.v4.app.Fragment", new EverythingGlobalScope(mProject));

        // Check for Activity class
        if ((activityClass != null && mClass.isInheritor(activityClass, true))
                || (compatActivityClass != null && mClass.isInheritor(compatActivityClass, true))
                || mClass.getName().contains("Activity")) {
            generatorLayoutCode("this", null);
            // Check for Fragment class
        } else if ((fragmentClass != null && mClass.isInheritor(fragmentClass, true)) || (supportFragmentClass != null && mClass.isInheritor(supportFragmentClass, true))) {
            generatorLayoutCode("getContext()", "rootView");
        }
    }

    /**
     * generatorLayoutCode
     *
     * @param contextName
     * @param findPre
     */
    protected void generatorLayoutCode(String contextName, String findPre) {
        StringBuilder initView = new StringBuilder();
        if (TextUtils.isEmpty(findPre)) {
            initView.append("private void _initView() {\n");
        } else {
            initView.append("private void _initView(View " + findPre + ") {\n");
        }
        for (Element element : mElements) {
            String pre = TextUtils.isEmpty(findPre) ? "" : findPre + ".";
            initView.append(element.getFieldName() + " = (" + element.name + ") " + pre + "findViewById(" + element.getFullID() + ");\n");
        }
        initView.append("}\n");
        PsiMethod[] initViewMethods = mClass.findMethodsByName("initView", false);
        if (initViewMethods.length > 0 && initViewMethods[0].getBody() != null) {
            PsiCodeBlock initViewMethodBody = initViewMethods[0].getBody();
            for (Element element : mElements) {
                if (!element.used) {
                    continue;
                }
                // remove duplicate field
                PsiField[] fields = mClass.getFields();
                boolean duplicateField = false;
                for (PsiField field : fields) {
                    String name = field.getName();
                    if (name != null && name.equals(element.getFieldName())) {
                        duplicateField = true;
                        break;
                    }
                }
                if (duplicateField) {
                    continue;
                }
                String pre = TextUtils.isEmpty(findPre) ? "" : findPre + ".";
                String s2 = element.getFieldName() + " = (" + element.name + ") " + pre + "findViewById(" + element.getFullID() + ");";
                initViewMethodBody.add(mFactory.createStatementFromText(s2, initViewMethods[0]));
            }
        } else {
            mClass.add(mFactory.createMethodFromText(initView.toString(), mClass));
        }
    }

    /**
     * generatorBindView
     */
    protected void generatorBindView() {
        for (Iterator<Element> iterator = mElements.iterator(); iterator.hasNext(); ) {
            Element element = iterator.next();

            if (!element.used) {
                continue;
            }

            // remove duplicate field
            PsiField[] fields = mClass.getFields();
            boolean duplicateField = false;
            for (PsiField field : fields) {
                String name = field.getName();
                if (name != null && name.equals(element.getFieldName())) {
                    duplicateField = true;
                    break;
                }
            }
            if (duplicateField) {
                continue;
            }
            mClass.add(mFactory.createFieldFromText(BindViewConfig.getBindView(mButterknife) + "(" + element.getFullID() + ")\nprivate " + element.name + " " + element.getFieldName() + ";", mClass));
        }
    }

    /**
     * generatorBindOnClick
     */
    protected void generatorBindOnClick() {
        List<Element> clickableElements = new ArrayList<Element>();
        for (Element element : mElements) {
            if (element.isClickable) {
                clickableElements.add(element);
            }
        }
        PsiMethod[] initViewMethods = mClass.findMethodsByName("bindOnClick", false);
        if (initViewMethods.length > 0 && initViewMethods[0].getBody() != null) {
        } else {
            if (clickableElements.size() > 0) {
                StringBuilder buider = new StringBuilder();
                StringBuilder caseBuider = new StringBuilder();
                buider.append(BindViewConfig.getBindOnClick(mButterknife) + "({");
                for (int i = 0; i < clickableElements.size(); i++) {
                    buider.append(clickableElements.get(i).getFullID());
                    if (i < clickableElements.size() - 1) {
                        buider.append(",");
                    }
                    caseBuider.append("case " + clickableElements.get(i).getFullID() + " :\n\nbreak;\n");
                }
                buider.append("})\n");
                mClass.add(mFactory.createMethodFromText(buider.toString() + "private void bindOnClick(View v){\nswitch (v.getId()) {\n" +
                        caseBuider.toString() +
                        "\t\t}\n" +
                        "}\n", mClass));
            }
        }
    }

    /**
     * generatorBindLongOnClick
     */
    protected void generatorBindLongOnClick() {
        List<Element> longClickableElements = new ArrayList<Element>();
        for (Element element : mElements) {
            if (element.isLongClickable) {
                longClickableElements.add(element);
            }
        }
        PsiMethod[] initViewMethods = mClass.findMethodsByName("bindLongOnClick", false);
        if (initViewMethods.length > 0 && initViewMethods[0].getBody() != null) {
        } else {
            if (longClickableElements.size() > 0) {
                StringBuilder buider = new StringBuilder();
                StringBuilder caseBuider = new StringBuilder();
                buider.append(BindViewConfig.getBindOnLongClick(mButterknife) + "({");
                for (int i = 0; i < longClickableElements.size(); i++) {
                    buider.append(longClickableElements.get(i).getFullID());
                    if (i < longClickableElements.size() - 1) {
                        buider.append(",");
                    }
                    caseBuider.append("case " + longClickableElements.get(i).getFullID() + " :\n\nbreak;\n");
                }
                buider.append("})\n");
                mClass.add(mFactory.createMethodFromText(buider.toString() + "private boolean bindLongOnClick(View v){\nswitch (v.getId()) {\n" +
                        caseBuider.toString() +
                        "\t\t}\n" +
                        "\t\treturn false;\n" +
                        "}\n", mClass));
            }
        }
    }

    /**
     * generatorEditSubmit
     */
    protected void generatorEditSubmit() {
        List<Element> editTextElements = new ArrayList<>();
        for (Element element : mElements) {
            // set flag
            if (element.isEditText) {
                editTextElements.add(element);
            }
        }
        PsiMethod[] initViewMethods = mClass.findMethodsByName("submit", false);
        if (initViewMethods.length > 0 && initViewMethods[0].getBody() != null) {
        } else {
            // generator EditText validate code if need
            StringBuilder sbEditText = new StringBuilder();
            if (editTextElements.size() > 0) {

                sbEditText.append("private void submit() {\n");
                sbEditText.append("\t\t// validate\n");

                for (Element element : editTextElements) {
                    // generator EditText string name
                    String idName = element.id;
                    int index = idName.lastIndexOf("_");
                    String name = index == -1 ? idName : idName.substring(index + 1);
                    if (name.equals(idName)) {
                        name += "String";
                    }
                    sbEditText.append("String " + name + " = " + idName + ".getText().toString().trim();\n");
                    sbEditText.append("if(StringUtils.isEmpty(" + name + ")) {\n");
                    String emptyTint = "\"" + name + "不能为空" + "\"";
                    String hint = element.xml.getAttributeValue("android:hint");
                    if (hint.startsWith("@string")) {
                        emptyTint = "R.string." + hint.replace("@string/", "");
                    } else if (!TextUtils.isEmpty(hint)) {
                        emptyTint = "\"" + hint + "\"";
                    }
                    sbEditText.append("ToastUtils.showToast(" + emptyTint + ");\n");
                    sbEditText.append("return;\n");
                    sbEditText.append("}\n");
                    sbEditText.append("\n");
                }
                sbEditText.append("\t\t// TODO validate success, do something\n");
                sbEditText.append("\t\t\n}\n");
            }
            if (editTextElements.size() > 0) {
                mClass.add(mFactory.createMethodFromText(sbEditText.toString(), mClass));
            }
        }
    }
}